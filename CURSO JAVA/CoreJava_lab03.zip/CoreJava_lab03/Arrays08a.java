/*
 * Crie um codigo que inicialize (utilizando a inicializa�ao com chaves {val1, val2,..}) 
 * um array de String de 5 posicoes com os seguintes valores:
 * 
 * 1: Cliente 1 email: cliente1@yahoo.com.br
 * 2: Cliente 2 email: cliente2@yahoo.com.br
 * 3: Cliente 3 email: cliente3@yahoo.com.br
 * 4: Cliente 4 email: cliente4@yahoo.com.br
 * 5: Cliente 5 email: cliente5@yahoo.com.br
 * 
 */
class Arrays08a {

    public static void main(String args[]) {
    }
}
