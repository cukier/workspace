/*
 * FomataDatas.java
 *
 */
package br.com.globalcode.datas;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

// 1. declare imports para as classes
// SimpleDateFormat, Calendar e Date
/**
 * 
 * @author Globalcode
 */
public class FomataDatas {

    public static void main(String[] args) {
        // 2. instancie um objeto calendar
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, 03);
        cal.set(Calendar.MONTH, Calendar.MARCH);
        cal.set(Calendar.YEAR, 1997);
        // 3. modifique os os componentes de tempo para a hora 18h57m0s
        cal.set(Calendar.HOUR, 18);
        cal.set(Calendar.MINUTE, 57);
        cal.set(Calendar.SECOND, 0);
        // 4. obtenha um objeto java.util.Date a partir do calendario e
        // guarde na vari�vel data.
        Date data = cal.getTime();
        System.out.println("data d1: " + data);
        // 5. construa um objeto de formatacao para obter
        // a seguinte formata��o: 03/Mar/97 e guarde na vari�vel formatador
        SimpleDateFormat formatador = new SimpleDateFormat("dd/MMM/yy");
        System.out.println("data formatada: " + formatador.format(data));
        System.out.println("data atual formatada: " + formatador.format(new Date()));
    }
}
