/*
 * Criar uma inst�ncia de Banco
 * Criar uma instancia de Agencia
 * Setar o atributo banco da Agencia com o banco criado
 * Criar uma inst�ncia de Cliente
 * Criar uma inst�ncia de Conta
 * Setar os atributos agencia e cliente da Conta, com a ag�ncia e cliente criados
 * Chame o m�todo imprime da Conta
 */
public class TesteClasses {
	public static void main(String[] args) {
		Banco banco = new Banco();
		banco.numero = 567;
		banco.nome = "Banco Globalcode";
		Agencia agencia = new Agencia();
		agencia.numero = "0876";
		agencia.nome = "Paraiso";
		agencia.banco = banco;
		Cliente cliente = new Cliente();
		cliente.nome = "Joao Cicero Silva";
		cliente.cpf = "657.980.976-87";
		Conta conta = new Conta();
		conta.numero = "08769-87";
		conta.saldo = 987.07;
		conta.agencia = agencia;
		conta.cliente = cliente;
		conta.imprime();
		conta.saque(500);
		conta.imprime();
		conta.deposito(550);
		conta.imprime();
	}
}