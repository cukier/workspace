class Cliente {
	String nome;
	String cpf;

	void imprime() {
		System.out.println("-------------------------");
		System.out.println("Nome do cliente: " + nome);
		System.out.println("CPF do cliente: " + cpf);
		System.out.println("-------------------------");
	}
}
