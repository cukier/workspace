class Agencia {
	String numero;
	String nome;
	Banco banco;

	void imprime() {
		System.out.println("-------------------------");
		System.out.println("Nome da agencia: " + nome);
		System.out.println("Numero da agencia: " + numero);
		banco.imprime();
		System.out.println("-------------------------");
	}
}
