class Conta {
	String numero;
	double saldo;
	Agencia agencia;
	Cliente cliente;

	void imprime() {
		System.out.println("-------------------------");
		System.out.println("Saldo da conta: " + saldo);
		System.out.println("Numero da conta: " + numero);
		agencia.imprime();
		cliente.imprime();
		System.out.println("-------------------------");
	}

	public void saque(double valor) {
		System.out.println("Realizando saque de R$ " + valor + " da conta "
				+ numero);
		if (valor > 0) {
			if (saldo >= valor) {
				saldo -= valor;
			} else
				System.out.println("Saldo insuficiente");
		} else {
			System.out.println("O valor de saque deve ser positivo");
		}
	}

	public void deposito(double valor) {
		System.out.println("Realizando deposito de R$" + valor + " da conta "
				+ numero);
		if (valor >= 0) {
			this.saldo += valor;
		} else
			System.out.println("O valor do deposito deve ser positivo");
	}
}
