/*
1) Analise o c�digo.

2) Inicialize as vari�veis declaradas com valores v�lidos.

3) Defina uma vari�vel idade do tipo para armazenar a idade da pessoa e inicialize.

4) Utilize o condicional if para atender as seguintes especificacoes:
 - Quando o sexo for masculino (M), deve ser impresso:
     O Senhor <nome da pessoa>, portador do rg... 
  - Quando o sexo for feminino (F), deve ser impresso:
     A Senhora <nome da pessoa>, portadora do rg ..
  - Quando o sexo for invalido (diferente de F ou M), deve ser impresso:
     O Senhor(a) <nome da pessoa>, portador(a)
  - Quando a pessoa for CLT, deve ser impresso:
     esta registrado com o salario de R$ <salario>
  - Quando a pessoa for Autonoma, deve ser impresso:
     foi contratado pelo valor de R$ <salario>
  
5) Ap�s a impress�o do texto, se a idade da pessoa estiver entre 16 e 18 anos, 
   imprimir �N�o esque�a de tirar seu t�tulo de eleitor!�.
   
6) Compile e execute a classe. Fa�a altera��o nos valores das vari�veis para 
   perceber a mudan�a nos resultados.
    
 */
public class DecalaracaoVariaveis {

	public static void main(String[] args) {
		// Declaracao das variaveis
		String nome;
		String dataNascimento;
		String rg;
		char sexo; // UTILIZE 'M' para MASCULINO e 'F' para FEMININO
		double salario;
		boolean clt;
		int idade;
		// Inicializacao
		nome = "Mariano da Cruz";
		dataNascimento = "10/12/1980";
		rg = "87.789.876";
		sexo = 'M'; // UTILIZE 'M' para MASCULINO e 'F' para FEMININO
		salario = 456.89;
		clt = true;
		idade = 17;
		// Linhas utilizadas caso nao haja uma defini�ao de qual o sexo da
		// pessoa - situa�ao default
		String textNome = "O(A) Senhor(a) " + nome + ", ";
		String textRg = "portador(a) do rg de numero " + rg + ", \n";
		// Executa a analise do sexo. Observe que estamos usando a variavel
		// textNome e textRg que foram inicializadas anteriormente.
		// Se declararmos dentro do bloco if estas Strings, nao conse-
		// guiremos utiliza-las posteriormente. Lembre-se do conceito de escopo!
		if (sexo == 'M') {
			textNome = "O Senhor " + nome + ", ";
			textRg = "portador do rg de numero " + rg + ", \n";
		} else if (sexo == 'F') {
			textNome = "A Senhora " + nome + ", ";
			textRg = "portadora do rg de numero " + rg + ", \n";
		}
		String textNasc = "nascido em " + dataNascimento + ", ";
		String textSexo = " do sexo " + sexo + ", ";
		// Inicializa�ao da variavel text$ que ira ser utilizada para imprimir
		// os dados do usuario.
		String text$ = "";
		// Note que estaremos reatribuindo um outro valor posteriormente
		if (clt) {
			text$ = " esta registrado com o salario de R$ " + salario;
		} else {
			text$ = " foi contratado pelo valor de R$ " + salario;
		}
		System.out.println(textNome + textRg + textNasc + textSexo + text$);

		// Impress�o do texto relativo � idade, se for o caso.
		if (idade >= 16 && idade < 18)
			System.out.println("N�o esque�a de tirar seu t�tulo de eleitor!");
	}
}
