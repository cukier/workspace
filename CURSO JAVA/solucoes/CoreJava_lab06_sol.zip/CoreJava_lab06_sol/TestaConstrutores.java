/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java 
 * 1) Construa um objeto da classe Conta com cada construtor e chame o metodo imprimeDados 
 * 2) Construa um objeto da classe Cliente e chame o metodo imprimeDados
 * 
 */
public class TestaConstrutores {

	public static void main(String[] args) {
		Banco banco = new Banco();
		banco.nome = "Banco Globalcode";
		banco.numero = 897;
		Agencia agencia = new Agencia("6587", banco);
		Cliente cli = new Cliente("Carlos Alberto Parreira", "589.564.587-78");
		cli.imprimeDados();
		Conta c = new Conta(2000, "5896-8", cli, agencia);
		c.imprimeDados();
		Conta c2 = new Conta("5854-7", cli, agencia);
		c2.imprimeDados();

	}
}
