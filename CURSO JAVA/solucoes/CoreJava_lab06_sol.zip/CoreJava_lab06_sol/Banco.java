class Banco {
	String nome;
	int numero;

	void imprime() {
		System.out.println("-------------------------");
		System.out.println("Nome do banco: " + nome);
		System.out.println("Numero do banco: " + numero);
		System.out.println("-------------------------");
	}
}
