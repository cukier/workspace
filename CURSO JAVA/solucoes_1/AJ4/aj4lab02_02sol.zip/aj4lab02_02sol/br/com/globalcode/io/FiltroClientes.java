/**
 * @author globalcode
 */
package br.com.globalcode.io;

import java.io.File;
import java.io.FilenameFilter;

public class FiltroClientes implements FilenameFilter {


    public boolean accept(File dir, String nomeDoArquivo) {
        
        /*
         * Instrucoes
         * ----------
         *
         * 1. Verifique se o nome do arquivo inicia com Cliente
         *     - utilize o metodo .startsWith("prefixo") dos objetos String
         *
         * 2. Verifique se o nome do arquivo termina com ".ser"
         *    - utilize o metodo .endsWith("sufixo") dos objetos String
         */
        boolean inicioOk = false;
        boolean extensaoOk = false;
        
        // solucao
        inicioOk = nomeDoArquivo.startsWith("Cliente");
        extensaoOk = nomeDoArquivo.endsWith(".ser");
        
        return inicioOk && extensaoOk;
    }
}
