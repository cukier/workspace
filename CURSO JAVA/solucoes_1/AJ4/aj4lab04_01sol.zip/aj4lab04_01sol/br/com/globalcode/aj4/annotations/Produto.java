/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 * 
 */
package br.com.globalcode.aj4.annotations;

import java.io.Serializable;


public class Produto implements Serializable{
	
	@GUIVisible(nomeCampo="C�digo:")
	private int codigo;
	
	@GUIVisible(nomeCampo="Descricao:")
	private String descricao;
	
	@GUIVisible(nomeCampo="Pre�o:")
	private double preco;
	
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
}
