public interface Tributavel {
    public String getDescricaoTributavel();
    public double calcularImpostos();
}
