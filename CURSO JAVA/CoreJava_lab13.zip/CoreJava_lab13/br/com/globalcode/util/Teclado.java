package br.com.globalcode.util;

import java.util.Scanner;

public class Teclado {

    /**
     * Este metodo e responsavel pela leitura de dados do teclado.
     * 
     * @return String com dados lidos do teclado
     */
    public static String le() {
    	Scanner s = new Scanner(System.in);
    	return s.next();
    }
}
