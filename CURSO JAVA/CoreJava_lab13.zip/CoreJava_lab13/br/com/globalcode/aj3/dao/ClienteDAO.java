/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 * 
 */
package br.com.globalcode.aj3.dao;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import br.com.globalcode.beans.Cliente;
import br.com.globalcode.util.GlobalcodeException;

/**
 * @author Globalcode
 * 
 */
public class ClienteDAO implements IClienteDAO {

    private final static String SALVAR_CLIENTE = "INSERT INTO clientes (nome,telefone, cpf) VALUES (?,?,?)";
    private final static String ATUALIZAR_CLIENTE = "UPDATE clientes SET nome=?, telefone= ? WHERE cpf = ?";
    private final static String CREATE_TABLE = "CREATE TABLE  IF NOT EXISTS  clientes (id int(3) NOT NULL AUTO_INCREMENT   PRIMARY KEY, nome VARCHAR(20) NOT NULL, cpf varchar(20) NOT NULL, telefone varchar(20) NOT NULL)";
    private final static String DELETE_CLIENTE = "DELETE FROM clientes WHERE cpf = '";
    private final static String GET_ALL_CLIENTES = "SELECT * FROM clientes";
    private final static String GET_CLIENTE_BY_CPF = "SELECT * FROM clientes WHERE cpf = ?";

    public void createTable() throws GlobalcodeException {
        Connection conn = null;
        Statement stmt = null;
        try {
            conn = ConnectionManager.getConexao();
            stmt = conn.createStatement();
            stmt.executeUpdate(CREATE_TABLE);
        } catch (SQLException e) {
            e.printStackTrace();
            throw new GlobalcodeException("Erro ao criar a tabela de clientes : " + CREATE_TABLE, e);
        } finally {
            ConnectionManager.closeAll(conn, stmt);
        }
    }

    /*
     * @see br.com.globalcode.aj3.dao.ClientesDAO#excluir(br.com.globalcode.beans.Cliente)
     */
    public void excluir(String cpf) throws GlobalcodeException {
        Connection conn = null;
        Statement stmt = null;
        try {
            conn = ConnectionManager.getConexao(); // Obtem uma conexao com o servidor
            stmt = conn.createStatement(); // Cria o statement responsavel pelo envio dos SQL's
            stmt.executeUpdate(DELETE_CLIENTE + cpf + "'"); // Executa a query passando como parametro o CPF
        } catch (SQLException e) {
            String errorMsg = "Nao foi possivel fechar o statement com o banco de Dados!";
            e.printStackTrace();
            throw new GlobalcodeException(errorMsg, e);
        }
    }

    /*
     * @see br.com.globalcode.aj3.dao.ClientesDAO#salvar(br.com.globalcode.beans.Cliente)
     */
    public void salvar(Cliente cliente) throws GlobalcodeException {
    	 // Criar uma variavel para a Conexao
        Connection conn = null;
        // Criar uma variavel para a PreparedStatement
        PreparedStatement stmt = null;
        try {
            // Obtem da ConnectionManager uma conexao com o banco de dados
            conn = ConnectionManager.getConexao();
            // Cria um preparedStatement para o BD conseguir pre-compilar um SQL previamente
            stmt = conn.prepareStatement(SALVAR_CLIENTE);
            // Atribui uma String para a 1a. interrogacao (nome)
            stmt.setString(1, cliente.getNome());
            // Atribui uma String para a 2a. interrogacao (telefone)
            stmt.setString(2, cliente.getTelefone());
            // Atribui uma String para a 3a. interrogacao (cpf)
            stmt.setString(3, cliente.getCpf());
            // Executar a operacao de gravar os dados na base
            stmt.executeUpdate();
        } catch (SQLException e) {
            GlobalcodeException.print(e, "Nao foi possivel salvar o cliente na base de dados.");
        } finally {
            // Finalizar o statement e a conexao usando a classe ConnectionManager
            ConnectionManager.closeAll(conn, stmt);
        }
    }

    /*
     * @see br.com.globalcode.aj3.dao.ClientesDAO#getAllClientes()
     */
    public List getAllClientes() throws GlobalcodeException {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        List clientes = new ArrayList();
        try {
            conn = ConnectionManager.getConexao();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(GET_ALL_CLIENTES);
            while (rs.next()) {
                Cliente cli = new Cliente(rs.getString("nome"), rs.getString("telefone"), rs.getString("cpf"), rs.getInt("id"));
                clientes.add(cli);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectionManager.closeAll(conn, stmt, rs);
        }
        return clientes;
    }

    /*
     * (non-Javadoc)
     * 
     * @see br.com.globalcode.aj3.dao.ClientesDAO#getClienteByID(int)
     */
    public Cliente getClienteByCPF(String cpf) throws GlobalcodeException {
        // Criar uma variavel para a Conexao
        // Criar uma variavel para a PreparedStatement
        // Criar uma variavel para o ResultSet
        // Obtem da ConnectionManager uma conexao com o banco de dados
        // Cria um preparedStatement para o BD conseguir pre compilar um SQL previamente
        // Atribui uma String para a 1a. interrogacao (cpf)
        // Executar a operacao de obter os dados na base
        // Executar a leitura do ResultSet, gerando um objeto Cliente para ser retornado pelo metodo
        // Finalizar o statement e a conexao usando a classe ConnectionManager
        // Retorna os valores para o metodo
    }
}
