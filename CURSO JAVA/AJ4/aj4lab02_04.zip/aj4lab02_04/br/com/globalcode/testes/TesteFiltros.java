package br.com.globalcode.testes;

import java.io.File;
import java.io.FilenameFilter;
import br.com.globalcode.util.FiltroGenerico;

public class TesteFiltros {
	public static void main(String args[]) {
		String nomeDiretorio = args[0];
		String extensao = args[1];
		File diretorio = new File(nomeDiretorio);
		if (diretorio.isDirectory()) {
			// Criando o filtro que mostra somente arquivos com a extensao
			// indicada
			FilenameFilter filtro = new FiltroGenerico(extensao);

			// Diretiva para listar os arquivos do diretorio, adicionando
			// habilidade de filtro
			String arquivos[] = diretorio.list(filtro);

			System.out.println("Lista de arquivos com a extensao :" + extensao);
			for (String nomeArquivo: arquivos) {
				System.out.println(nomeArquivo);
			}
		} else {
			System.out.println("Nao é um diretorio");
		}
	}
}
