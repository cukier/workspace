package br.com.globalcode.io;

import br.com.globalcode.util.GlobalcodeException;

/*
 * Importante:
 * Este codigo sera utilizado pela classe EditorTexto por isto:
 *  
 * 1. Nao altere a assinatura dos metodos desta classe, ou seja, mantenha todos 
 * os modificadores, os parametros e as exceptions lançadas.
 * 2. Nao altere o nome desta classe
 * 
 * OBS: Na abertura dos arquivos, o texto aberto estara deslocado em relaçao a
 * atual tela. Para confirmar a abertura do arquivo, utilize as barras de rolagem 
 * na tela de edição.
 * 
 */
public class FileSaver {

	public static void save(String texto, String fileName)
			throws GlobalcodeException {

	}

	public static String read(String fileName) throws GlobalcodeException {

		return null; // o valor null deve ser trocado pela String lida no método

	}
}
